"use strict";

let messages = require('./lib/messages');
let emailvalidator = require('email-validator');
let isvalidbirthdate = require('is-valid-birthdate');

module.exports = {
	messages,
	emailvalidator,
	isvalidbirthdate
}