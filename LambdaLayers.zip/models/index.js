"use strict";

let dao = require('./lib/index);

module.exports = {
	dao
}